# @Time    : 2023/10/13 17:24
# @Author  : Zixian He
# @File    : solver_qp.py.py
# @Description :
import gurobipy as gp
import cvxpy as cp
from solver import Solver


def getSOCPCR(data):
    # 获取数据
    N = data.u_num
    T = data.t_num
    load = data.load
    reserve = data.reserve
    r_up = data.r_up
    r_down = data.r_down
    alpha = data.alpha
    beta = data.beta
    gamma = data.gama
    min_output = data.min_output
    max_output = data.max_output
    t_init = data.t_init
    P0 = data.p_init
    t_on = data.t_on
    t_off = data.t_off
    c_h = data.c_h
    c_c = data.c_c
    t_c = data.t_c
    r_on = data.r_on
    r_off = data.r_off
    u0 = data.u0
    U = []
    for i in range(N):
        U.append(max(
            0, min(T, u0[i] * (t_on[i] - t_init[i]))))
    L = []
    for i in range(N):
        L.append(max(0, min(
            T, (1 - u0[i]) * (t_off[i] + t_init[i]))))
    # build model

    # variables
    # 转化为 SDP 所需变量
    P = cp.Variable(shape=(N, T), nonneg=True, name="P")
    z = cp.Variable(shape=(N, T), nonneg=True, name="z")
    SC = cp.Variable(shape=(N, T), nonneg=True, name="SC")
    u = cp.Variable(shape=(N, T), name="u")
    v = cp.Variable(shape=(N, T), name="v")
    w = cp.Variable(shape=(N, T), name="w")

    # 约束
    constr = []
    constr.append(u >= 0)
    constr.append(u <= 1)
    constr.append(v >= 0)
    constr.append(v <= 1)
    constr.append(w >= 0)
    constr.append(w <= 1)

    # SOCP constraints
    for i in range(N):
        for t in range(T):
            # Rotate SOCP
            constr.append(cp.PowCone3D(u[i, t], z[i, t], P[i, t], 1 / 2))
            # General SOCP
            # constr.append(cp.SOC(u[i, t] + z[i, t], cp.vstack([2 * P[i, t], z[i, t] - u[i, t]])))

    # Startup constraints
    for i in range(N):
        for t in range(T):
            constr.append(SC[i, t] >= (c_c[i] - c_h[i]) * (v[i, t] - sum(w[i, (max(1, t + 1 - t_off[i] - t_c[i]) - 1): t]) - (
                1 if (t + 1 - t_off[i] - t_c[i] <= 0 and max(0, -t_init[i]) < abs(t + 1 - t_off[i] - t_c[i] - 1) + 1) else 0)))

    # Power balance constraints
    for t in range(T):
        constr.append(sum(P[:, t]) == load[t])

    # System spinning reserve requirements
    for t in range(T):
        constr.append(sum(u[i, t] * max_output[i] for i in range(N)) >= load[t] + reserve[t])

    # Unit generation limits
    for i in range(N):
        for t in range(T):
            constr.append(u[i, t] * min_output[i] <= P[i, t])
            constr.append(P[i, t] <= u[i, t] * max_output[i])

    # Ramp rete limits
    for i in range(N):
        for t in range(T):
            constr.append(P[i, t] - (P0[i] if t == 0 else P[i, t - 1]) <= (u0[i] if t == 0 else u[i, t - 1]) * r_up[i] + v[i, t] * r_on[i])
            constr.append((P0[i] if t == 0 else P[i, t - 1]) - P[i, t] <= u[i, t] * r_down[i] + w[i, t] * r_off[i])

    # Minimum uptime and downtime constraints
    for i in range(N):
        for t in range(U[i], T):
            constr.append(sum(v[i, (max(0, t + 1 - t_on[i])): t + 1]) <= u[i, t])
        for t in range(L[i], T):
            constr.append(sum(w[i, (max(0, t + 1 - t_off[i])): t + 1]) <= 1 - u[i, t])

    # State variables and logical constraints
    for i in range(N):
        for t in range(T):
            constr.append(v[i, t] - w[i, t] == u[i, t] - (u0[i] if t == 0 else u[i, t - 1]))

    # Initial status of units
    for i in range(N):
        for t in range(U[i] + L[i]):
            constr.append(u[i, t] == u0[i])

    # const = sum(alpha[i] * u[i, t] + beta[i] * P[i, t] + gamma[i] * z[i, t] + v[i, t] * c_h[i] + SC[i, t] for i in range(N) for t in range(T))
    obj = cp.Minimize(sum(u.T @ alpha) + sum(P.T @ beta) + sum(z.T @ gamma) + sum(v.T @ c_h) + cp.sum(SC))
    prob = cp.Problem(obj, constr)
    prob.solve(solver=cp.MOSEK, verbose=True)
    # print("status: ", prob.status)
    # print("solve time: ", round(prob.solver_stats.solve_time, 4))
    # print("optimal value: ", round(obj.value, 4))
    # Get tau and upsilon

    return [prob.solver_stats.solve_time, round(obj.value, 4), u.value, P.value]


class QPSolver(Solver):

    def solve(self):
        """
        求解
        :return:
        """
        data = self.data
        t_num = data.t_num
        u_num = data.u_num
        load = data.load
        reserve = data.reserve
        r_up = data.r_up
        r_down = data.r_down
        alpha = data.alpha
        beta = data.beta
        gama = data.gama
        min_output = data.min_output
        max_output = data.max_output
        t_init = data.t_init
        p_init = data.p_init
        t_on = data.t_on
        t_off = data.t_off
        c_h = data.c_h
        c_c = data.c_c
        t_c = data.t_c
        r_on = data.r_on
        r_off = data.r_off
        u0 = data.u0

        # 投影模型，相应变量做变换
        if self.org_or_proj == 1:
            alpha = [alpha[i] + beta[i] * min_output[i] + gama[i] * (min_output[i] ** 2) for i in range(u_num)]
            beta = [(max_output[i] - min_output[i]) * (beta[i] + 2 * gama[i] * min_output[i]) for i in range(u_num)]
            gama = [gama[i] * ((max_output[i] - min_output[i]) ** 2) for i in range(u_num)]
            r_up = [r_up[i] / (max_output[i] - min_output[i]) for i in range(u_num)]
            r_down = [r_down[i] / (max_output[i] - min_output[i]) for i in range(u_num)]
            p_init = [(p_init[i] - u0[i] * min_output[i]) / (max_output[i] - min_output[i]) for i in range(u_num)]
            r_on = [(r_on[i] - min_output[i]) / (max_output[i] - min_output[i]) for i in range(u_num)]
            r_off = [(r_off[i] - min_output[i]) / (max_output[i] - min_output[i]) for i in range(u_num)]

        rc = list([(i, t) for i in range(1, u_num + 1) for t in range(1, t_num + 1)])
        # 最小启停需要的变量
        W = []
        for i in range(1, u_num + 1):
            W.append(max(
                0, min(t_num, u0[i - 1] * (t_on[i - 1] - t_init[i - 1]))))
        L = []
        for i in range(1, u_num + 1):
            L.append(max(0, min(
                t_num, (1 - u0[i - 1]) * (t_off[i - 1] + t_init[i - 1]))))

        upsilon = {key: [] for key in rc}
        tau = {key: [] for key in rc}
        if self.model_type == 2:
            # 计算 QCR 系数
            # socp_cr = QPSolver(data, self.gurobi_params, 1, self.org_or_proj, 1)
            [socp_time, socp_obj, socp_u, socp_P] = getSOCPCR(data)
            self.Runtime_cr = socp_time
            for i in range(1, u_num + 1):
                for t in range(1, t_num + 1):
                    if socp_u[i - 1, t - 1] == 0:
                        upsilon[i, t] = 0
                        tau[i, t] = 0
                    else:
                        upsilon[i, t] = -2 * gama[i - 1] * (socp_P[i - 1, t - 1] / socp_u[i - 1, t - 1])
                        tau[i, t] = gama[i - 1] * ((socp_P[i - 1, t - 1] / socp_u[i - 1, t - 1]) ** 2)
                        if abs(upsilon[i, t]) < 1e-10 or tau[i, t] < 1e-10:
                            upsilon[i, t] = 0
                            tau[i, t] = 0

        try:
            # Model start
            m = gp.Model("QP")
            # Create variables
            # org_or_cr == 1 : CR
            if self.org_or_cr == 1:
                u = m.addVars(rc, lb=0.0, ub=1.0, vtype=gp.GRB.CONTINUOUS, name="u")
                v = m.addVars(rc, lb=0.0, ub=1.0, vtype=gp.GRB.CONTINUOUS, name="v")
                w = m.addVars(rc, lb=0.0, ub=1.0, vtype=gp.GRB.CONTINUOUS, name="w")
            else:
                u = m.addVars(rc, vtype=gp.GRB.BINARY, name="u")
                v = m.addVars(rc, vtype=gp.GRB.BINARY, name="v")
                w = m.addVars(rc, vtype=gp.GRB.BINARY, name="w")
            p = m.addVars(rc, lb=0, vtype=gp.GRB.CONTINUOUS, name="p")
            sc = m.addVars(rc, lb=0, vtype=gp.GRB.CONTINUOUS, name="sc")
            if self.model_type == 1:
                z = m.addVars(rc, lb=0, vtype=gp.GRB.CONTINUOUS, name="z")

            # Objective function
            if self.model_type == 0:
                m.setObjective(gp.quicksum(
                    alpha[i - 1] * u[i, t] + beta[i - 1] * p[i, t] + gama[i - 1] * (p[i, t] ** 2) + v[i, t] * c_h[i - 1] + sc[i, t] for i in
                    range(1, u_num + 1) for t in
                    range(1, t_num + 1)), gp.GRB.MINIMIZE)
            elif self.model_type == 1:
                m.setObjective(gp.quicksum(
                    alpha[i - 1] * u[i, t] + beta[i - 1] * p[i, t] + gama[i - 1] * z[i, t] + v[i, t] * c_h[i - 1] + sc[i, t] for i in
                    range(1, u_num + 1) for t in
                    range(1, t_num + 1)), gp.GRB.MINIMIZE)
            elif self.model_type == 2:
                m.setObjective(gp.quicksum(
                    alpha[i - 1] * u[i, t] + beta[i - 1] * p[i, t] + gama[i - 1] * (p[i, t] ** 2) + v[i, t] * c_h[i - 1] + sc[i, t] + tau[i, t] * (
                            (u[i, t] ** 2) - u[i, t]) +
                    upsilon[i, t] * (u[i, t] * p[i, t] - p[i, t]) for i in range(1, u_num + 1) for t in
                    range(1, t_num + 1)), gp.GRB.MINIMIZE)

            # Constraints start

            # SOCP 二阶锥约束
            if self.model_type == 1:
                m.addConstrs((p[i, t] ** 2 <= u[i, t] * z[i, t] for i in range(1, u_num + 1) for t in range(1, t_num + 1)),
                             name="SOC constraints 1")

            # startup cost —— Multi-Period Locally-Facet-Based MIP Formulations for Unit Commitment Problems:(6)
            m.addConstrs((sc[i, t] >= (c_c[i - 1] - c_h[i - 1]) * (
                    v[i, t] - gp.quicksum(w[i, j] for j in range(max(1, t - t_off[i - 1] - t_c[i - 1]), t)) - (
                1 if (t - t_off[i - 1] - t_c[i - 1]) <= 0 and max(0, -t_init[i - 1]) < abs(t - t_off[i - 1] - t_c[i - 1] - 1) + 1 else 0)) for i in
                          range(1, u_num + 1) for t in
                          range(1, t_num + 1)), name="startup cost constraints")

            # power balance constraints (4) or (23)
            if self.org_or_proj == 0:
                m.addConstrs((gp.quicksum(p[i, t] for i in range(1, u_num + 1)) == load[t - 1] for t in range(1, t_num + 1)),
                             name="power balance constraints")
            else:
                m.addConstrs((gp.quicksum(
                    p[i, t] * (max_output[i - 1] - min_output[i - 1]) + u[i, t] * min_output[i - 1] for i in range(1, u_num + 1)) == load[t - 1] for t
                              in range(1, t_num + 1)), name="power balance constraints")

            # system spinning reserve requirements (5)
            m.addConstrs((
                gp.quicksum(u[i, t] * max_output[i - 1] for i in range(1, u_num + 1)) >= load[t - 1] +
                reserve[t - 1] for t in range(1, t_num + 1)), name="spinning reserve requirements")

            # unit generation limits (6) or (24)
            if self.org_or_proj == 0:
                m.addConstrs((p[i, t] >= u[i, t] * min_output[i - 1] for i in range(1, u_num + 1) for t in range(1, t_num + 1)),
                             name="unit generation limits 1")
                m.addConstrs((p[i, t] <= u[i, t] * max_output[i - 1] for i in range(1, u_num + 1) for t in range(1, t_num + 1)),
                             name="unit generation limits 2")
            else:
                m.addConstrs((p[i, t] <= u[i, t] for i in range(1, u_num + 1) for t in range(1, t_num + 1)), name="unit generation limits")

            # ramp rate limits (7) (8)
            m.addConstrs(
                (p[i, t] - (p[i, t - 1] if t > 1 else p_init[i - 1]) <= (u[i, t - 1] if t > 1 else u0[i - 1]) * r_up[i - 1] + v[i, t] *
                 r_on[i - 1] for i in range(1, u_num + 1) for t in range(1, t_num + 1)), name="ramp rate limits 1")
            m.addConstrs(
                ((p[i, t - 1] if t > 1 else p_init[i - 1]) - p[i, t] <= u[i, t] * r_down[i - 1] + w[i, t] * r_off[i - 1] for i in range(1, u_num + 1)
                 for t in range(1, t_num + 1)), name="ramp rate limits 2")

            # ramp rate limits —— Multi-Period Locally-Facet-Based MIP Formulations for Unit Commitment Problems:(14)-(17)
            # if self.org_or_proj == 0:
            #     m.addConstrs(
            #         (p[i, t] <= u[i, t] * max_output[i - 1] - v[i, t] * (max_output[i - 1] - r_on[i - 1]) for i in range(1, u_num + 1) for t in
            #          range(1, t_num + 1)), name="ramp rate limits 1.1")
            #     m.addConstrs((p[i, t] - (p[i, t - 1] if t > 1 else p_init[i - 1]) <= u[i, t] * (r_up[i - 1] + min_output[i - 1]) - (
            #         u[i, t - 1] if t > 1 else u0[i - 1]) * min_output[i - 1] + v[i, t] * (r_on[i - 1] - r_up[i - 1] - min_output[i - 1]) for i in
            #                   range(1, u_num + 1) for t in range(1, t_num + 1)), name="ramp rate limits 1.2")
            #     m.addConstrs(
            #         (p[i, t] <= u[i, t] * max_output[i - 1] - w[i, t + 1] * (max_output[i - 1] - r_off[i - 1]) for i in range(1, u_num + 1) for t in
            #          range(1, t_num)), name="ramp rate limits 2.1")
            #     m.addConstrs(((p[i, t - 1] if t > 1 else p_init[i - 1]) - p[i, t] <= (u[i, t - 1] if t > 1 else u0[i - 1]) * (
            #             r_down[i - 1] + min_output[i - 1]) - u[i, t] * min_output[i - 1] + w[i, t] * (
            #                           r_off[i - 1] - r_down[i - 1] - min_output[i - 1]) for i in range(1, u_num + 1) for t in range(1, t_num + 1)),
            #                  name="ramp rate limits 2.2")
            # else:
            #     m.addConstrs((p[i, t] <= u[i, t] - v[i, t] * (1 - r_on[i - 1]) for i in range(1, u_num + 1) for t in range(1, t_num + 1)),
            #                  name="ramp rate limits 1.1")
            #     m.addConstrs(
            #         (p[i, t] - (p[i, t - 1] if t > 1 else p_init[i - 1]) <= u[i, t] * r_up[i - 1] + v[i, t] * (r_on[i - 1] - r_up[i - 1]) for i in
            #          range(1, u_num + 1) for t in range(1, t_num + 1)),
            #         name="ramp rate limits 1.2")
            #     m.addConstrs((p[i, t] <= u[i, t] - w[i, t + 1] * (1 - r_off[i - 1]) for i in range(1, u_num + 1) for t in range(1, t_num)),
            #                  name="ramp rate limits 2.1")
            #     m.addConstrs(
            #         ((p[i, t - 1] if t > 1 else p_init[i - 1]) - p[i, t] <= (u[i, t - 1] if t > 1 else u0[i - 1]) * r_down[i - 1] + w[i, t] * (
            #                 r_off[i - 1] - r_down[i - 1]) for i in range(1, u_num + 1) for t in range(1, t_num + 1)), name="ramp rate limits 2.2")

            # minimum uptime and downtime constraints can be formulated (9)(10)
            m.addConstrs(
                (gp.quicksum(v[i, j] for j in range(max(0, t - t_on[i - 1]) + 1, t + 1)) <= u[i, t] for i in range(1, u_num + 1) for t
                 in range(W[i - 1] + 1, t_num + 1)), name="minimum on time constraints")
            m.addConstrs(
                (gp.quicksum(w[i, j] for j in range(max(0, t - t_off[i - 1]) + 1, t + 1)) <= 1 - u[i, t] for i in range(1, u_num + 1)
                 for t in range(L[i - 1] + 1, t_num + 1)), name="maximum off time constraints")

            #  state variables and logical constraints (11)
            m.addConstrs(
                (v[i, t] - w[i, t] == u[i, t] - (u[i, t - 1] if t > 1 else u0[i - 1]) for i in range(1, u_num + 1) for t in range(1, t_num + 1)),
                name="logical constraints")

            # initial status of units
            m.addConstrs(
                (u[i, t] == u0[i - 1] for i in range(1, u_num + 1)
                 for t in range(1, W[i - 1] + L[i - 1] + 1)),
                name="initial status constraints")

            # Constraints end

            # Model end

            # Compute optimal cost

            # 设置 gurobi 参数
            for key, value in self.gurobi_params.items():
                if self.org_or_cr == 1 and key == "MIPGap":
                    continue
                m.setParam(key, value)

            # 求解
            m.update()
            m.optimize()
            # 获取并保存求解后的结果
            self.ObjVal = m.getAttr("ObjVal")
            if self.org_or_cr == 0:
                self.MIPGap = m.getAttr("MIPGap")
            self.Runtime = m.getAttr("Runtime")
            self.p = {key: [] for key in rc}
            for i in range(1, u_num + 1):
                for t in range(1, t_num + 1):
                    self.p[i, t] = m.getVarByName("p[%d,%d]" % (i, t)).x
            self.u = {key: [] for key in rc}
            for i in range(1, u_num + 1):
                for t in range(1, t_num + 1):
                    self.u[i, t] = m.getVarByName("u[%d,%d]" % (i, t)).x
            self.v = {key: [] for key in rc}
            for i in range(1, u_num + 1):
                for t in range(1, t_num + 1):
                    self.v[i, t] = m.getVarByName("v[%d,%d]" % (i, t)).x
            self.w = {key: [] for key in rc}
            for i in range(1, u_num + 1):
                for t in range(1, t_num + 1):
                    self.w[i, t] = m.getVarByName("w[%d,%d]" % (i, t)).x
            self.sc = {key: [] for key in rc}
            for i in range(1, u_num + 1):
                for t in range(1, t_num + 1):
                    self.sc[i, t] = m.getVarByName("sc[%d,%d]" % (i, t)).x
        except gp.GurobiError as e:
            print('Error code ' + str(e))
        except AttributeError as e:
            print('Encountered an attribute error' + str(e))

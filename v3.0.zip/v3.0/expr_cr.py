# @Time    : 2024/1/5 16:42
# @Author  : Zixian He
# @File    : expr_cr.py
# @Description : Getting all the continuous relaxation.

from data_reader import DataReader
from solver_qp import QPSolver

model_list = ["qp", "socp", "qcr_rmosek_1"]
print()
print("**10Unit**")
for k in [2]:
    print()
    print("*{}*".format(model_list[k]))
    print()
    for i in range(1, 6):
        data = DataReader("Data/10Unit/10_0_{}_w.mod".format(i))
        print()
        print("Data/10Unit/10_0_{}_w.mod".format(i))
        print()
        s = QPSolver(data, {"Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 1, 0, k)
        s.write_in_file("10Unit/cr/{}.out".format(model_list[k]))
        del s

print()
print("**20Unit**")
for k in [2]:
    print()
    print("*{}*".format(model_list[k]))
    print()
    for i in range(1, 6):
        data = DataReader("Data/20Unit/20_0_{}_w.mod".format(i))
        print()
        print("Data/20Unit/20_0_{}_w.mod".format(i))
        print()
        s = QPSolver(data, {"Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 1, 0, k)
        s.write_in_file("20Unit/cr/{}.out".format(model_list[k]))
        del s

print()
print("**50Unit**")
for k in [2]:
    print()
    print("*{}*".format(model_list[k]))
    print()
    for i in range(1, 6):
        data = DataReader("Data/50Unit/50_0_{}_w.mod".format(i))
        print()
        print("Data/50Unit/50_0_{}_w.mod".format(i))
        print()
        s = QPSolver(data, {"Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 1, 0, k)
        s.write_in_file("50Unit/cr/{}.out".format(model_list[k]))
        del s

print()
print("**75Unit**")
for k in [2]:
    print()
    print("*{}*".format(model_list[k]))
    print()
    for i in range(1, 6):
        data = DataReader("Data/75Unit/75_0_{}_w.mod".format(i))
        print()
        print("Data/75Unit/75_0_{}_w.mod".format(i))
        print()
        s = QPSolver(data, {"Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 1, 0, k)
        s.write_in_file("75Unit/cr/{}.out".format(model_list[k]))
        del s

print()
print("**100Unit**")
for k in [2]:
    print()
    print("*{}*".format(model_list[k]))
    print()
    for i in range(1, 6):
        data = DataReader("Data/100Unit/100_0_{}_w.mod".format(i))
        print()
        print("Data/100Unit/100_0_{}_w.mod".format(i))
        print()
        s = QPSolver(data, {"Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 1, 0, k)
        s.write_in_file("100Unit/cr/{}.out".format(model_list[k]))
        del s

print()
print("**150Unit**")
for k in [2]:
    print()
    print("*{}*".format(model_list[k]))
    print()
    for i in range(1, 6):
        data = DataReader("Data/150Unit/150_0_{}_w.mod".format(i))
        print()
        print("Data/150Unit/150_0_{}_w.mod".format(i))
        print()
        s = QPSolver(data, {"Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 1, 0, k)
        s.write_in_file("150Unit/cr/{}.out".format(model_list[k]))
        del s

print()
print("**200Unit**")
for k in [2]:
    print()
    print("*{}*".format(model_list[k]))
    print()
    for i in range(1, 13):
        data = DataReader("Data/200Unit/200_0_{}_w.mod".format(i))
        print()
        print("Data/200Unit/200_0_{}_w.mod".format(i))
        print()
        s = QPSolver(data, {"Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 1, 0, k)
        s.write_in_file("200Unit/cr/{}.out".format(model_list[k]))
        del s

print()
print("**Based8std**")
for k in [2]:
    print()
    print("*{}*".format(model_list[k]))
    print()
    for i in range(1, 21):
        data = DataReader("Data/Based8Std/c{}_based_8_std.mod".format(i))
        print()
        print("Data/Based8Std/c{}_based_8_std.mod".format(i))
        print()
        s = QPSolver(data, {"Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 1, 0, k)
        s.write_in_file("Based8Std/cr/{}.out".format(model_list[k]))
        del s

from data_reader import DataReader


class Solver:

    def solve(self):
        """
        调用求解器，子类重写
        :return:
        """
        pass

    def __init__(self, data, gurobi_params, org_or_cr, org_or_proj, model_type):
        """
        :param file_path: 求解样例文件的路径
        :param gurobi_params: 包含参数和参数值的字典
        :param org_or_cr: 0 - MIP or 1 - cr
        :param org_or_proj: 0 - MIP or 1 - P-MIP
        :param model_type: 0 - QP, 1 - SOCP/PC, 2 - QCR
        """
        self.data = data
        self.gurobi_params = gurobi_params
        self.org_or_cr = org_or_cr
        self.org_or_proj = org_or_proj
        self.model_type = model_type
        self.ObjVal = -1
        if self.org_or_cr == 0:
            self.MIPGap = -1
        self.Runtime = -1
        if model_type == 2:
            self.Runtime_cr = -1
            self.socp_cr = None
        self.p = []
        self.u = []
        self.v = []
        self.w = []
        self.sc = []
        self.solve()

    def write_in_file(self, file):
        """
        将求解结果写入文件
        :param file: Out/file
        :return:
        """
        with open("Out/" + file, "a+") as f:
            if self.org_or_cr == 0:
                if self.model_type == 2:
                    print("ObjVal: %.4f, Gap: %.6f, Runtime_cr: %.4f, Runtime_qcr: %.4f, Runtime_sum: %.4f" % (
                        self.ObjVal, self.MIPGap, self.Runtime_cr, self.Runtime, self.Runtime + self.Runtime_cr), file=f)
                else:
                    print("ObjVal: %.4f, Gap: %.6f, Runtime: %.4f" % (self.ObjVal, self.MIPGap, self.Runtime), file=f)
            else:
                if self.model_type == 2:
                    print("ObjVal: %.4f, Runtime_cr: %.4f, Runtime_qcr: %.4f, Runtime_sum: %.4f" % (
                        self.ObjVal, self.Runtime_cr, self.Runtime, self.Runtime + self.Runtime_cr), file=f)
                else:
                    print("ObjVal: %.4f, Runtime: %.4f" % (self.ObjVal, self.Runtime), file=f)

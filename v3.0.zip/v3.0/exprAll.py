# @Time    : 2023/12/30 16:34
# @Author  : Zixian He
# @File    : exprAll.py
# @Description : Running all experiments.

from data_reader import DataReader
from solver_qp import QPSolver

model_list = ["qp", "socp", "qcr_rmosek"]
# print("***1***")
# print()
# print("**10Unit**")
# for k in range(0, 3):
#     print()
#     print("*{}*".format(model_list[k]))
#     print()
#     for i in range(1, 6):
#         data = DataReader("Data/10Unit/10_0_{}_w.mod".format(i))
#         print()
#         print("Data/10Unit/10_0_{}_w.mod".format(i))
#         print()
#         s = QPSolver(data, {"MIPGap": 1e-4, "Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 0, 0, k)
#         s.write_in_file("10Unit/1/{}.out".format(model_list[k]))
#         del s

# print()
# print("**20Unit**")
# for k in range(0, 3):
#     print()
#     print("*{}*".format(model_list[k]))
#     print()
#     for i in range(1, 6):
#         data = DataReader("Data/20Unit/20_0_{}_w.mod".format(i))
#         print()
#         print("Data/20Unit/20_0_{}_w.mod".format(i))
#         print()
#         s = QPSolver(data, {"MIPGap": 1e-4, "Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 0, 0, k)
#         s.write_in_file("20Unit/1/{}.out".format(model_list[k]))
#         del s

# print()
# print("**50Unit**")
# for k in range(0, 3):
#     print()
#     print("*{}*".format(model_list[k]))
#     print()
#     for i in range(1, 6):
#         data = DataReader("Data/50Unit/50_0_{}_w.mod".format(i))
#         print()
#         print("Data/50Unit/50_0_{}_w.mod".format(i))
#         print()
#         s = QPSolver(data, {"MIPGap": 1e-4, "Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 0, 0, k)
#         s.write_in_file("50Unit/1/{}.out".format(model_list[k]))
#         del s

# print()
# print("**75Unit**")
# for k in range(0, 3):
#     print()
#     print("*{}*".format(model_list[k]))
#     print()
#     for i in range(1, 6):
#         data = DataReader("Data/75Unit/75_0_{}_w.mod".format(i))
#         print()
#         print("Data/75Unit/75_0_{}_w.mod".format(i))
#         print()
#         s = QPSolver(data, {"MIPGap": 1e-4, "Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 0, 0, k)
#         s.write_in_file("75Unit/1/{}.out".format(model_list[k]))
#         del s

# print()
# print("**100Unit**")
# for k in range(0, 3):
#     print()
#     print("*{}*".format(model_list[k]))
#     print()
#     for i in range(1, 6):
#         data = DataReader("Data/100Unit/100_0_{}_w.mod".format(i))
#         print()
#         print("Data/100Unit/100_0_{}_w.mod".format(i))
#         print()
#         s = QPSolver(data, {"MIPGap": 1e-4, "Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 0, 0, k)
#         s.write_in_file("100Unit/1/{}.out".format(model_list[k]))
#         del s


# print()
# print("**150Unit**")
# for k in range(0, 3):
#     print()
#     print("*{}*".format(model_list[k]))
#     print()
#     for i in range(1, 6):
#         data = DataReader("Data/150Unit/150_0_{}_w.mod".format(i))
#         print()
#         print("Data/150Unit/150_0_{}_w.mod".format(i))
#         print()
#         s = QPSolver(data, {"MIPGap": 1e-4, "Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 0, 0, k)
#         s.write_in_file("150Unit/1/{}.out".format(model_list[k]))
#         del s


# print()
# print("**200Unit**")
# for k in range(0, 3):
#     print()
#     print("*{}*".format(model_list[k]))
#     print()
#     for i in range(1, 13):
#         data = DataReader("Data/200Unit/200_0_{}_w.mod".format(i))
#         print()
#         print("Data/200Unit/200_0_{}_w.mod".format(i))
#         print()
#         s = QPSolver(data, {"MIPGap": 1e-4, "Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 0, 0, k)
#         s.write_in_file("200Unit/1/{}.out".format(model_list[k]))
#         del s


# print()
# print("**Based8std**")
# for k in range(0, 3):
#     print()
#     print("*{}*".format(model_list[k]))
#     print()
#     for i in range(1, 21):
#         data = DataReader("Data/Based8Std/c{}_based_8_std.mod".format(i))
#         print()
#         print("Data/Based8Std/c{}_based_8_std.mod".format(i))
#         print()
#         s = QPSolver(data, {"MIPGap": 1e-4, "Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 0, 0, k)
#         s.write_in_file("Based8Std/1/{}.out".format(model_list[k]))
#         del s

# print("***2***")
# print()
# print("**10Unit**")
# for k in range(0, 3):
#     print()
#     print("*{}*".format(model_list[k]))
#     print()
#     for i in range(1, 6):
#         data = DataReader("Data/10Unit/10_0_{}_w.mod".format(i))
#         print()
#         print("Data/10Unit/10_0_{}_w.mod".format(i))
#         print()
#         s = QPSolver(data, {"MIPGap": 5e-4, "Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 0, 0, k)
#         s.write_in_file("10Unit/2/{}.out".format(model_list[k]))
#         del s

# print()
# print("**20Unit**")
# for k in range(0, 3):
#     print()
#     print("*{}*".format(model_list[k]))
#     print()
#     for i in range(1, 6):
#         data = DataReader("Data/20Unit/20_0_{}_w.mod".format(i))
#         print()
#         print("Data/20Unit/20_0_{}_w.mod".format(i))
#         print()
#         s = QPSolver(data, {"MIPGap": 5e-4, "Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 0, 0, k)
#         s.write_in_file("20Unit/2/{}.out".format(model_list[k]))
#         del s

# print()
# print("**50Unit**")
# for k in range(0, 3):
#     print()
#     print("*{}*".format(model_list[k]))
#     print()
#     for i in range(1, 6):
#         data = DataReader("Data/50Unit/50_0_{}_w.mod".format(i))
#         print()
#         print("Data/50Unit/50_0_{}_w.mod".format(i))
#         print()
#         s = QPSolver(data, {"MIPGap": 5e-4, "Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 0, 0, k)
#         s.write_in_file("50Unit/2/{}.out".format(model_list[k]))
#         del s

# print()
# print("**75Unit**")
# for k in range(0, 3):
#     print()
#     print("*{}*".format(model_list[k]))
#     print()
#     for i in range(1, 6):
#         data = DataReader("Data/75Unit/75_0_{}_w.mod".format(i))
#         print()
#         print("Data/75Unit/75_0_{}_w.mod".format(i))
#         print()
#         s = QPSolver(data, {"MIPGap": 5e-4, "Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 0, 0, k)
#         s.write_in_file("75Unit/2/{}.out".format(model_list[k]))
#         del s

# print()
# print("**100Unit**")
# for k in range(0, 3):
#     print()
#     print("*{}*".format(model_list[k]))
#     print()
#     for i in range(1, 6):
#         data = DataReader("Data/100Unit/100_0_{}_w.mod".format(i))
#         print()
#         print("Data/100Unit/100_0_{}_w.mod".format(i))
#         print()
#         s = QPSolver(data, {"MIPGap": 5e-4, "Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 0, 0, k)
#         s.write_in_file("100Unit/2/{}.out".format(model_list[k]))
#         del s

# print()
# print("**150Unit**")
# for k in range(0, 3):
#     print()
#     print("*{}*".format(model_list[k]))
#     print()
#     for i in range(1, 6):
#         data = DataReader("Data/150Unit/150_0_{}_w.mod".format(i))
#         print()
#         print("Data/150Unit/150_0_{}_w.mod".format(i))
#         print()
#         s = QPSolver(data, {"MIPGap": 5e-4, "Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 0, 0, k)
#         s.write_in_file("150Unit/2/{}.out".format(model_list[k]))
#         del s

# print()
# print("**200Unit**")
# for k in range(0, 3):
#     print()
#     print("*{}*".format(model_list[k]))
#     print()
#     for i in range(1, 13):
#         data = DataReader("Data/200Unit/200_0_{}_w.mod".format(i))
#         print()
#         print("Data/200Unit/200_0_{}_w.mod".format(i))
#         print()
#         s = QPSolver(data, {"MIPGap": 5e-4, "Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 0, 0, k)
#         s.write_in_file("200Unit/2/{}.out".format(model_list[k]))
#         del s

# print()
# print("**Based8std**")
# for k in range(0, 3):
#     print()
#     print("*{}*".format(model_list[k]))
#     print()
#     for i in range(1, 21):
#         data = DataReader("Data/Based8Std/c{}_based_8_std.mod".format(i))
#         print()
#         print("Data/Based8Std/c{}_based_8_std.mod".format(i))
#         print()
#         s = QPSolver(data, {"MIPGap": 5e-4, "Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 0, 0, k)
#         s.write_in_file("Based8Std/2/{}.out".format(model_list[k]))
#         del s




# print("***3***")
# print()
# print("**10Unit**")
# for k in range(0, 3):
#     print()
#     print("*{}*".format(model_list[k]))
#     print()
#     for i in range(1, 6):
#         data = DataReader("Data/10Unit/10_0_{}_w.mod".format(i))
#         print()
#         print("Data/10Unit/10_0_{}_w.mod".format(i))
#         print()
#         s = QPSolver(data, {"MIPGap": 1e-3, "Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 0, 0, k)
#         s.write_in_file("10Unit/3/{}.out".format(model_list[k]))
#         del s

# print()
# print("**20Unit**")
# for k in range(0, 3):
#     print()
#     print("*{}*".format(model_list[k]))
#     print()
#     for i in range(1, 6):
#         data = DataReader("Data/20Unit/20_0_{}_w.mod".format(i))
#         print()
#         print("Data/20Unit/20_0_{}_w.mod".format(i))
#         print()
#         s = QPSolver(data, {"MIPGap": 1e-3, "Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 0, 0, k)
#         s.write_in_file("20Unit/3/{}.out".format(model_list[k]))
#         del s

# print()
# print("**50Unit**")
# for k in range(0, 3):
#     print()
#     print("*{}*".format(model_list[k]))
#     print()
#     for i in range(1, 6):
#         data = DataReader("Data/50Unit/50_0_{}_w.mod".format(i))
#         print()
#         print("Data/50Unit/50_0_{}_w.mod".format(i))
#         print()
#         s = QPSolver(data, {"MIPGap": 1e-3, "Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 0, 0, k)
#         s.write_in_file("50Unit/3/{}.out".format(model_list[k]))
#         del s

# print()
# print("**75Unit**")
# for k in range(0, 3):
#     print()
#     print("*{}*".format(model_list[k]))
#     print()
#     for i in range(1, 6):
#         data = DataReader("Data/75Unit/75_0_{}_w.mod".format(i))
#         print()
#         print("Data/75Unit/75_0_{}_w.mod".format(i))
#         print()
#         s = QPSolver(data, {"MIPGap": 1e-3, "Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 0, 0, k)
#         s.write_in_file("75Unit/3/{}.out".format(model_list[k]))
#         del s

# print()
# print("**100Unit**")
# for k in range(0, 3):
#     print()
#     print("*{}*".format(model_list[k]))
#     print()
#     for i in range(1, 6):
#         data = DataReader("Data/100Unit/100_0_{}_w.mod".format(i))
#         print()
#         print("Data/100Unit/100_0_{}_w.mod".format(i))
#         print()
#         s = QPSolver(data, {"MIPGap": 1e-3, "Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 0, 0, k)
#         s.write_in_file("100Unit/3/{}.out".format(model_list[k]))
#         del s

# print()
# print("**150Unit**")
# for k in range(0, 3):
#     print()
#     print("*{}*".format(model_list[k]))
#     print()
#     for i in range(1, 6):
#         data = DataReader("Data/150Unit/150_0_{}_w.mod".format(i))
#         print()
#         print("Data/150Unit/150_0_{}_w.mod".format(i))
#         print()
#         s = QPSolver(data, {"MIPGap": 1e-3, "Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 0, 0, k)
#         s.write_in_file("150Unit/3/{}.out".format(model_list[k]))
#         del s

# print()
# print("**200Unit**")
# for k in range(0, 3):
#     print()
#     print("*{}*".format(model_list[k]))
#     print()
#     for i in range(1, 13):
#         data = DataReader("Data/200Unit/200_0_{}_w.mod".format(i))
#         print()
#         print("Data/200Unit/200_0_{}_w.mod".format(i))
#         print()
#         s = QPSolver(data, {"MIPGap": 1e-3, "Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 0, 0, k)
#         s.write_in_file("200Unit/3/{}.out".format(model_list[k]))
#         del s

# print()
# print("**Based8std**")
# for k in range(0, 3):
#     print()
#     print("*{}*".format(model_list[k]))
#     print()
#     for i in range(1, 21):
#         data = DataReader("Data/Based8Std/c{}_based_8_std.mod".format(i))
#         print()
#         print("Data/Based8Std/c{}_based_8_std.mod".format(i))
#         print()
#         s = QPSolver(data, {"MIPGap": 1e-3, "Threads": 8, "TimeLimit": 3600, "OutputFlag": 1}, 0, 0, k)
#         s.write_in_file("Based8Std/3/{}.out".format(model_list[k]))
#         del s

